var annotated_dup =
[
    [ "audio_lib_t", "structaudio__lib__t.html", "structaudio__lib__t" ],
    [ "audio_sample_node", "structaudio__sample__node.html", "structaudio__sample__node" ],
    [ "char_stats_t", "structchar__stats__t.html", null ],
    [ "dsonar_config_t", "structdsonar__config__t.html", "structdsonar__config__t" ],
    [ "dsonar_result_t", "structdsonar__result__t.html", "structdsonar__result__t" ],
    [ "mojibake_partition_t", "structmojibake__partition__t.html", null ],
    [ "mojibake_target_t", "structmojibake__target__t.html", null ],
    [ "reverse_sample_node", "structreverse__sample__node.html", "structreverse__sample__node" ],
    [ "se_data", "structse__data.html", null ],
    [ "sonar_config_t", "structsonar__config__t.html", "structsonar__config__t" ]
];