var files_dup =
[
    [ "lib", "dir_97aefd0d527b934f1d99a682da8fe6a9.html", "dir_97aefd0d527b934f1d99a682da8fe6a9" ],
    [ "mojibake", "dir_ae9b8d9f799bd108d50814add95099a6.html", "dir_ae9b8d9f799bd108d50814add95099a6" ],
    [ "mojibake_sonar.c", "mojibake__sonar_8c.html", "mojibake__sonar_8c" ]
];