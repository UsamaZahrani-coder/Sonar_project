var searchData=
[
  ['2_3a_20implement_20your_20module_0',['Step 2: Implement Your Module',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md3',1,'']]]
];
