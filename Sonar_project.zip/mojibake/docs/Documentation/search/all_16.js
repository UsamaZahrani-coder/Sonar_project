var searchData=
[
  ['your_20module_0',['Step 2: Implement Your Module',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md3',1,'']]],
  ['your_20own_20extensions_1',['How to Create Your Own Extensions',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md1',1,'']]]
];
