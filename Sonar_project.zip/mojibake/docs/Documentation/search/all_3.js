var searchData=
[
  ['about_0',['About',['../index.html#autotoc_md13',1,'']]],
  ['add_20to_20main_20program_1',['Step 3: Add to Main Program',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md4',1,'']]],
  ['add_5freverse_5fsample_2',['add_reverse_sample',['../mbx__dsonar_8h.html#aa0a97033912c585c29ddf563cd348574',1,'mbx_dsonar.c']]],
  ['add_5fsample_5fto_5flist_3',['add_sample_to_list',['../mbx__sonar_8h.html#a5ff9d31c62347485e97dcbd0ab6485ab',1,'mbx_sonar.c']]],
  ['amplitude_4',['amplitude',['../structaudio__sample__node.html#aa2beb17905b47a656068b852a93ec4d3',1,'audio_sample_node']]],
  ['analyze_5fwav_5ffrequencies_5',['analyze_wav_frequencies',['../mbx__dsonar_8h.html#add1f07ca896984d2ad8b830abb2ef7b4',1,'mbx_dsonar.h']]],
  ['apply_5faudio_5feffect_6',['apply_audio_effect',['../audio__engine_8h.html#a47dcae18d6ab25278078ec4067f47745',1,'audio_engine.c']]],
  ['audio_5fapi_7',['AUDIO_API',['../audio__engine_8h.html#a8c51eb032bd081c35abfffd3a9d1aad1',1,'audio_engine.h']]],
  ['audio_5fengine_2eh_8',['audio_engine.h',['../audio__engine_8h.html',1,'']]],
  ['audio_5flib_5ft_9',['audio_lib_t',['../structaudio__lib__t.html',1,'']]],
  ['audio_5fsample_5fnode_10',['audio_sample_node',['../structaudio__sample__node.html',1,'']]],
  ['audio_5fsample_5fnode_5ft_11',['audio_sample_node_t',['../audio__engine_8h.html#a31366a42552388405c8ccf5615181085',1,'audio_sample_node_t:&#160;audio_engine.h'],['../mbx__sonar_8h.html#a31366a42552388405c8ccf5615181085',1,'audio_sample_node_t:&#160;mbx_sonar.h']]],
  ['auto_5fdetect_5fand_5freconstruct_12',['auto_detect_and_reconstruct',['../mbx__dsonar_8h.html#a0ceff7e06406c10c71a3c1c0b63aa906',1,'mbx_dsonar.h']]],
  ['available_20data_13',['Available Data',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md5',1,'']]],
  ['average_5fconfidence_14',['average_confidence',['../structdsonar__result__t.html#a113d27dcad883e72bfdd6ff1e3d0096c',1,'dsonar_result_t']]]
];
