var searchData=
[
  ['base_5ffrequency_0',['base_frequency',['../structdsonar__config__t.html#ab4ed9e95152d3588fd3e29c503f760aa',1,'dsonar_config_t::base_frequency'],['../structsonar__config__t.html#aa8036f2ed4822d1bb2703dcdc8af3717',1,'sonar_config_t::base_frequency']]],
  ['batch_5freconstruct_5fpartitions_1',['batch_reconstruct_partitions',['../mbx__dsonar_8h.html#acc0ae0e867296f429efe398c97bfaf95',1,'mbx_dsonar.h']]]
];
