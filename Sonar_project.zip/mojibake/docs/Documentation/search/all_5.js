var searchData=
[
  ['calculate_5fconfidence_0',['calculate_confidence',['../mbx__dsonar_8h.html#a663584b0986166e03715f0171a04fdae',1,'mbx_dsonar.h']]],
  ['calculate_5freconstruction_5faccuracy_1',['calculate_reconstruction_accuracy',['../mbx__dsonar_8h.html#a3d18fda858a37cc91e5926fbcb80f5be',1,'mbx_dsonar.c']]],
  ['char_5fstats_5ft_2',['char_stats_t',['../structchar__stats__t.html',1,'']]],
  ['cleanup_5faudio_3',['cleanup_audio',['../structaudio__lib__t.html#a4dd1aa4b30277da40d52c2b6389613c0',1,'audio_lib_t::cleanup_audio'],['../audio__engine_8h.html#a6d839acc43a95d848db0e9777e61c9a3',1,'cleanup_audio(void):&#160;audio_engine.c']]],
  ['combine_5fpartition_5ffiles_4',['combine_partition_files',['../mbx__dsonar_8h.html#a1e162c5f7e51d7bde3e03fcdcfb39031',1,'mbx_dsonar.c']]],
  ['compilation_5',['Compilation',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md7',1,'']]],
  ['confidence_5fscore_6',['confidence_score',['../structreverse__sample__node.html#a5632a62f88bbda25fbb79a7b5784db6b',1,'reverse_sample_node']]],
  ['create_20header_20file_7',['Step 1: Create Header File',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md2',1,'']]],
  ['create_20your_20own_20extensions_8',['How to Create Your Own Extensions',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md1',1,'']]],
  ['create_5faudio_5fsample_9',['create_audio_sample',['../mbx__sonar_8h.html#ae03ae7536803ba3fe0e9168fcdb8c13b',1,'mbx_sonar.c']]],
  ['create_5freverse_5fsample_10',['create_reverse_sample',['../mbx__dsonar_8h.html#abb024982230b1d5dd1770bc921eb0969',1,'mbx_dsonar.c']]]
];
