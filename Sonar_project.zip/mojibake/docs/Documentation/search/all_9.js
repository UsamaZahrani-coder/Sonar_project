var searchData=
[
  ['generate_5fanalysis_5freport_0',['generate_analysis_report',['../structaudio__lib__t.html#a028cf54180d9c4ba1699a4af2b68b3af',1,'audio_lib_t::generate_analysis_report'],['../audio__engine_8h.html#a352d5db6a5754ebfe944486b3f2f7b99',1,'generate_analysis_report():&#160;audio_engine.c']]],
  ['generate_5ffrequency_5fdata_1',['generate_frequency_data',['../structaudio__lib__t.html#a607dad205ccf0ebea53984823cfd2b15',1,'audio_lib_t::generate_frequency_data'],['../audio__engine_8h.html#ab52ae0676cb5c79ad636fd85d3c25600',1,'generate_frequency_data():&#160;audio_engine.c']]],
  ['generate_5fmetadata_5fjson_2',['generate_metadata_json',['../structaudio__lib__t.html#a611abdcd1ec72fa2ee595e5c3ff07634',1,'audio_lib_t::generate_metadata_json'],['../audio__engine_8h.html#a5e6fc8a5079c1c39fca3f196facfcd64',1,'generate_metadata_json():&#160;audio_engine.c']]],
  ['generate_5fwav_3',['generate_wav',['../structaudio__lib__t.html#a0e0162e9aebe33ccd907d829f0be0beb',1,'audio_lib_t::generate_wav'],['../audio__engine_8h.html#a9380783725d1637c1f6dd75fef57ed6e',1,'generate_wav(const char *filename, audio_sample_node_t *samples):&#160;audio_engine.c']]],
  ['generate_5fwav_5ffile_4',['generate_wav_file',['../mbx__sonar_8h.html#aaa02eb009c4eda76d58e1ac4f4735e8f',1,'mbx_sonar.c']]],
  ['get_5faudio_5fdevices_5',['get_audio_devices',['../audio__engine_8h.html#ac25419b376b65c192a0fee2b914077ec',1,'audio_engine.c']]],
  ['get_5flibrary_5fname_6',['get_library_name',['../audio__engine_8h.html#a3f818031ec7898746c3be39c5f223602',1,'audio_engine.c']]],
  ['get_5flibrary_5fversion_7',['get_library_version',['../audio__engine_8h.html#a9bec6c16c8b2509c200468b33ec2fd22',1,'audio_engine.c']]],
  ['get_5fsupported_5fsample_5frates_8',['get_supported_sample_rates',['../audio__engine_8h.html#a297bd4d6e006217d4c12e47376ac6c13',1,'audio_engine.c']]],
  ['getting_20started_9',['Getting Started',['../index.html#autotoc_md10',1,'']]],
  ['guide_10',['Mojibake Extension Development Guide',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html',1,'']]]
];
