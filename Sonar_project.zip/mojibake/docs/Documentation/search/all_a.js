var searchData=
[
  ['header_20file_0',['Step 1: Create Header File',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md2',1,'']]],
  ['how_20to_20create_20your_20own_20extensions_1',['How to Create Your Own Extensions',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md1',1,'']]]
];
