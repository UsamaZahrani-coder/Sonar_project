var searchData=
[
  ['next_0',['next',['../structaudio__sample__node.html#a652d17ff52a2598fcc87c5c3a14cf3b7',1,'audio_sample_node::next'],['../structreverse__sample__node.html#a376018544639f3a12213427054397e26',1,'reverse_sample_node::next']]]
];
