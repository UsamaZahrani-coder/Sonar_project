var searchData=
[
  ['char_5fstats_5ft_0',['char_stats_t',['../structchar__stats__t.html',1,'']]]
];
