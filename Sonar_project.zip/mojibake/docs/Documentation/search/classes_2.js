var searchData=
[
  ['dsonar_5fconfig_5ft_0',['dsonar_config_t',['../structdsonar__config__t.html',1,'']]],
  ['dsonar_5fresult_5ft_1',['dsonar_result_t',['../structdsonar__result__t.html',1,'']]]
];
