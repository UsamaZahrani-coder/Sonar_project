var searchData=
[
  ['mojibake_5fpartition_5ft_0',['mojibake_partition_t',['../structmojibake__partition__t.html',1,'']]],
  ['mojibake_5ftarget_5ft_1',['mojibake_target_t',['../structmojibake__target__t.html',1,'']]]
];
