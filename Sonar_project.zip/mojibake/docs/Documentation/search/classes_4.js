var searchData=
[
  ['reverse_5fsample_5fnode_0',['reverse_sample_node',['../structreverse__sample__node.html',1,'']]]
];
