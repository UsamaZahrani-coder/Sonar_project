var searchData=
[
  ['add_5freverse_5fsample_0',['add_reverse_sample',['../mbx__dsonar_8h.html#aa0a97033912c585c29ddf563cd348574',1,'mbx_dsonar.c']]],
  ['add_5fsample_5fto_5flist_1',['add_sample_to_list',['../mbx__sonar_8h.html#a5ff9d31c62347485e97dcbd0ab6485ab',1,'mbx_sonar.c']]],
  ['analyze_5fwav_5ffrequencies_2',['analyze_wav_frequencies',['../mbx__dsonar_8h.html#add1f07ca896984d2ad8b830abb2ef7b4',1,'mbx_dsonar.h']]],
  ['apply_5faudio_5feffect_3',['apply_audio_effect',['../audio__engine_8h.html#a47dcae18d6ab25278078ec4067f47745',1,'audio_engine.c']]],
  ['auto_5fdetect_5fand_5freconstruct_4',['auto_detect_and_reconstruct',['../mbx__dsonar_8h.html#a0ceff7e06406c10c71a3c1c0b63aa906',1,'mbx_dsonar.h']]]
];
