var searchData=
[
  ['samples_5fto_5fbytes_0',['samples_to_bytes',['../mbx__dsonar_8h.html#a6489ee02f61b0c72d3bc1938c739e107',1,'mbx_dsonar.c']]],
  ['save_5freconstructed_5fdata_1',['save_reconstructed_data',['../mbx__dsonar_8h.html#aed20cc453f90d9a499ed0232a42a4f1b',1,'mbx_dsonar.c']]],
  ['set_5faudio_5fdevice_2',['set_audio_device',['../audio__engine_8h.html#aa44dfab92ed3b5c1580ee04eddef8b33',1,'audio_engine.c']]],
  ['set_5fmaster_5fvolume_3',['set_master_volume',['../audio__engine_8h.html#a80d19a75498d66759a14b5fd97bc75e3',1,'audio_engine.c']]]
];
