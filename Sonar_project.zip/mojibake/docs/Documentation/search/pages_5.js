var searchData=
[
  ['data_0',['Available Data',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html#autotoc_md5',1,'']]],
  ['development_20guide_1',['Mojibake Extension Development Guide',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html',1,'']]],
  ['documentation_2',['Mojibake SONAR Documentation',['../index.html',1,'']]]
];
