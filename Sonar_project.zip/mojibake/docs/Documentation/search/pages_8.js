var searchData=
[
  ['getting_20started_0',['Getting Started',['../index.html#autotoc_md10',1,'']]],
  ['guide_1',['Mojibake Extension Development Guide',['../md__e_x_t_e_n_s_i_o_n___g_u_i_d_e.html',1,'']]]
];
