var searchData=
[
  ['layout_0',['Repository Layout',['../index.html#autotoc_md11',1,'']]],
  ['license_1',['License',['../index.html#autotoc_md12',1,'']]]
];
