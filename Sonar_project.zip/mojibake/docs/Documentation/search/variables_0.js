var searchData=
[
  ['amplitude_0',['amplitude',['../structaudio__sample__node.html#aa2beb17905b47a656068b852a93ec4d3',1,'audio_sample_node']]],
  ['average_5fconfidence_1',['average_confidence',['../structdsonar__result__t.html#a113d27dcad883e72bfdd6ff1e3d0096c',1,'dsonar_result_t']]]
];
