var searchData=
[
  ['base_5ffrequency_0',['base_frequency',['../structdsonar__config__t.html#ab4ed9e95152d3588fd3e29c503f760aa',1,'dsonar_config_t::base_frequency'],['../structsonar__config__t.html#aa8036f2ed4822d1bb2703dcdc8af3717',1,'sonar_config_t::base_frequency']]]
];
