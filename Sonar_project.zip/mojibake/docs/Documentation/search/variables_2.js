var searchData=
[
  ['cleanup_5faudio_0',['cleanup_audio',['../structaudio__lib__t.html#a4dd1aa4b30277da40d52c2b6389613c0',1,'audio_lib_t']]],
  ['confidence_5fscore_1',['confidence_score',['../structreverse__sample__node.html#a5632a62f88bbda25fbb79a7b5784db6b',1,'reverse_sample_node']]]
];
