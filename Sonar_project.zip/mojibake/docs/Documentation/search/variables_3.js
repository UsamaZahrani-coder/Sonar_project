var searchData=
[
  ['data_5flength_0',['data_length',['../structdsonar__result__t.html#a53f01f03cc0a71c1f8b7a49e5cef3552',1,'dsonar_result_t']]],
  ['duration_1',['duration',['../structaudio__sample__node.html#adead9e657c6b5600ea88dd4690a4ee6a',1,'audio_sample_node']]]
];
