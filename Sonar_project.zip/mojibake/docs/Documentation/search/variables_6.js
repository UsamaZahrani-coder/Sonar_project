var searchData=
[
  ['init_5faudio_0',['init_audio',['../structaudio__lib__t.html#a1e16a4b0c952366fad0dc94ddcc87751',1,'audio_lib_t']]],
  ['input_5fformat_1',['input_format',['../structdsonar__config__t.html#a840e70f782bac6320d0c40dabcefa7c4',1,'dsonar_config_t']]]
];
