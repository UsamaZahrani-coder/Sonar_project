var searchData=
[
  ['reconstructed_5fbyte_0',['reconstructed_byte',['../structreverse__sample__node.html#aaa393f4180cb5038a35daeb755c829a5',1,'reverse_sample_node']]],
  ['reconstructed_5fdata_1',['reconstructed_data',['../structdsonar__result__t.html#a2968023d8d3ca5935d70708fa723e0fe',1,'dsonar_result_t']]]
];
