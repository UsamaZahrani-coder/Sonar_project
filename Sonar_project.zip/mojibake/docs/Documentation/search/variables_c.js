var searchData=
[
  ['tolerance_0',['tolerance',['../structdsonar__config__t.html#a9c5fe586d10c52092361d8da9644291c',1,'dsonar_config_t']]],
  ['total_5fsamples_1',['total_samples',['../structdsonar__result__t.html#a27d72c4449b428ac170d74d92977ee36',1,'dsonar_result_t']]]
];
