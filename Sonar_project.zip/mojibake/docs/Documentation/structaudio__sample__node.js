var structaudio__sample__node =
[
    [ "amplitude", "structaudio__sample__node.html#aa2beb17905b47a656068b852a93ec4d3", null ],
    [ "duration", "structaudio__sample__node.html#adead9e657c6b5600ea88dd4690a4ee6a", null ],
    [ "frequency", "structaudio__sample__node.html#adf80ee13dd8b919451daa9c9f0e24b5b", null ],
    [ "next", "structaudio__sample__node.html#a652d17ff52a2598fcc87c5c3a14cf3b7", null ],
    [ "source_byte", "structaudio__sample__node.html#ae53473828b68ee48897d805600e50ac0", null ]
];