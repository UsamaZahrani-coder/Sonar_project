var structdsonar__config__t =
[
    [ "base_frequency", "structdsonar__config__t.html#ab4ed9e95152d3588fd3e29c503f760aa", null ],
    [ "frequency_range", "structdsonar__config__t.html#a2b3cf481aef49002e7f02f9086f9bd7c", null ],
    [ "input_format", "structdsonar__config__t.html#a840e70f782bac6320d0c40dabcefa7c4", null ],
    [ "strict_mode", "structdsonar__config__t.html#a547e5dc2f51edd6d7bd85f2ee8f4c087", null ],
    [ "tolerance", "structdsonar__config__t.html#a9c5fe586d10c52092361d8da9644291c", null ]
];