var structdsonar__result__t =
[
    [ "average_confidence", "structdsonar__result__t.html#a113d27dcad883e72bfdd6ff1e3d0096c", null ],
    [ "data_length", "structdsonar__result__t.html#a53f01f03cc0a71c1f8b7a49e5cef3552", null ],
    [ "reconstructed_data", "structdsonar__result__t.html#a2968023d8d3ca5935d70708fa723e0fe", null ],
    [ "successful_samples", "structdsonar__result__t.html#a35efe06adac17166d0e9431d8e6ba1b5", null ],
    [ "total_samples", "structdsonar__result__t.html#a27d72c4449b428ac170d74d92977ee36", null ]
];