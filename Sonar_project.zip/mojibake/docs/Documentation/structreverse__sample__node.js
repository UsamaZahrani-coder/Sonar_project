var structreverse__sample__node =
[
    [ "confidence_score", "structreverse__sample__node.html#a5632a62f88bbda25fbb79a7b5784db6b", null ],
    [ "next", "structreverse__sample__node.html#a376018544639f3a12213427054397e26", null ],
    [ "reconstructed_byte", "structreverse__sample__node.html#aaa393f4180cb5038a35daeb755c829a5", null ],
    [ "sample_index", "structreverse__sample__node.html#a2f6276c3a84bf20b3772e9a2b492310f", null ],
    [ "source_frequency", "structreverse__sample__node.html#ae1bac7df4c49a5bf86b3ac81fbc5f73c", null ]
];