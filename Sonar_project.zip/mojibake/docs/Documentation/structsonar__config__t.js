var structsonar__config__t =
[
    [ "base_frequency", "structsonar__config__t.html#aa8036f2ed4822d1bb2703dcdc8af3717", null ],
    [ "frequency_range", "structsonar__config__t.html#a69aa437d95f30071dca442519cff4de0", null ],
    [ "sample_duration", "structsonar__config__t.html#ae5ddbdadf261d7255ecf5dbb5a158a28", null ],
    [ "sample_rate", "structsonar__config__t.html#a8fabd4ef1c42d637322b9c1b173bddff", null ],
    [ "use_dynamic_lib", "structsonar__config__t.html#aeb2a88a690564718687ceaeb7a8ca45f", null ]
];